import { Component } from '@angular/core';

@Component({
  selector: 'app-agregar-editar-inventario',
  standalone: true,
  imports: [],
  templateUrl: './agregar-editar-inventario.component.html',
  styleUrl: './agregar-editar-inventario.component.css'
})
export class AgregarEditarInventarioComponent {

}
