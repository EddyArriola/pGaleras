export interface Inventario{
    InventarioID?: number,
    FechaIngreso: string;
    FechaVenta: string;
    CantidadIngreso: number
    CantidadVenta:number
    Existencias:number
    HuevosProduccion: number
}